local M = {}

function M:peek() end

function M:seek() end

function M:fetch() return 1 end

function M:preload() return 1 end

return M
