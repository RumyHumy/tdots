#![allow(clippy::module_inception)]

mod fs;

pub use fs::*;
